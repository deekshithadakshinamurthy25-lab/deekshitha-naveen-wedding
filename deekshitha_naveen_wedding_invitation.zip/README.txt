DEEKSHITHA & NAVEENKUMAR — WEDDING INVITATION

Files:
- index.html: complete responsive invitation webpage
- assets/couple-photo.jpg: your uploaded couple photo

PREVIEW:
Open index.html in a browser to preview the page locally.

PUBLISH WITH GITHUB PAGES:
1. Sign in or create an account at https://github.com
2. Create a new public repository named: deekshitha-naveen-wedding
3. Upload index.html and the assets folder (including couple-photo.jpg) to the repository root.
4. In the repository, open Settings -> Pages.
5. Under Build and deployment, choose "Deploy from a branch"; choose branch "main" and folder "/ (root)", then Save.
6. Wait for GitHub Pages to publish. The URL will look like:
   https://YOUR-GITHUB-USERNAME.github.io/deekshitha-naveen-wedding/
Replace YOUR-GITHUB-USERNAME with your actual GitHub username.

The URL does not have a built-in 3-day expiry, but continued availability depends on the GitHub account/repository remaining public and enabled.

EVENT DETAILS:
Reception: Saturday, 14 November 2026, 6:00 PM
Wedding: Sunday, 15 November 2026, 7:00 AM–8:30 AM
Venue: Kalaingar Kottam, Kattur, Thiruvarur

Please check all details and the map search result before sharing widely.
